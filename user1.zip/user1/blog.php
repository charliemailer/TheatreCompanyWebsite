<!doctype html>
<head>
<?php
require_once("php/page.class.php");
$page = new Page();
?>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="style/style.css">
</head>

<body>

<a href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>

<nav>
<ul class="navbar">
<?php echo $page->getMenu(); ?>
</ul>
</nav>
<div class="banner">
	<img src="assets/MainBanner.jpg" class="img-fluid">
</div>
<h1>Blog</h1>

<main>
<?php
$now=new DateTime();
$page->getArticles($now->format("Y-m-d H:i:s O"), 2, "DESC");
echo $page->displayArticles();
?>
</main>
</body>


<script src="js/article.js"></script>
<script>
document.onreadystatechange = function(){
	if(document.readyState=="complete") {
		var articlehandler=new Article("main");
	}
}
</script>
</html>
