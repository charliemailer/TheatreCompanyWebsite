<!doctype html>
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
<a  href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>
<?php
require_once("php/page.class.php");
require_once("php/userlist.class.php");
$page = new Page(3);
?>
<nav>
<ul class="navbar">
<?php echo $page->getMenu(); ?>
</ul>
</nav>
<h1>System Admin</h1>
<p>Use the drop down list to view all registered users and their edit details.</p>
<br>
<br>
<align="center" form method="post" action="editother.php">
<?php
$userlist = new UserList();
echo $userlist;
?>
<button type="submit">Edit User</button>
</form>
</body>
</html>