<?php
require_once("page.class.php");
$page = new Page();
$blogpostdate=$_POST['blogpostdate'];
if($page->getArticles($blogpostdate, 1, "PREV")>0) {
	echo json_encode($page->articlesToArray());
} else {
	$result=array("None");
	echo json_encode($result);
}

?>
