<!doctype html>
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>

<?php
require_once("php/page.class.php");
require_once("php/util.class.php");
$page = new Page(3);
?>

<a href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>  


<nav>
<ul class="navbar">
<?php echo $page->getMenu(); ?>
</ul>
</nav>


<h1>Edit Article</h1>

<form method="post" action="aarticle.php">
	<fieldset><legend>Edit Article</legend>
	<label for="title">Title </label><input type="text" name="title" id="title" required size="40" /><br />
	<label for="content">Content</label><textarea name="content" id="content" cols="60" rows="8"></textarea><br />
	<button type="submit">Edit Article</button>
	</fieldset>
	</form>
<main>
<?php
if(util::posted($_GET['aid'])) {
	$aid=util::sanInt($_GET['aid']);
	$articletoedit=new Article();
	$result=$articletoedit->getArticleById($aid);
	if($result) {
		echo "<h2>Article Details</h2>";
		
	} else { 
		echo "<h2>Could not retrieve article</h2>";
	}
}
?>
</main>
</body>
</html>



