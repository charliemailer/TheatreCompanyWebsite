<?php
require_once("php/page.class.php");
$page = new Page();
$page->logout();

?>