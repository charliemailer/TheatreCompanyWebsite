<!doctype html>
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>

<?php
require_once("php/page.class.php");
$page = new Page(2);
?>


<a href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>

<nav>
<ul class="navbar">
<?php echo $page->getMenu(); ?>
</ul>
</nav>


<h1>User Panel</h1>
<?php
echo $page->getUser(); 
?>


<p><a href="editself.php">Edit Details</a></p>
</body>
</html>