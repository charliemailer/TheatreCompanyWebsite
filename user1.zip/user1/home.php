<!doctype html>
<head>
<?php
require_once("php/page.class.php");
$page = new Page();
?>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="style/style.css">
</head>

<body>

<a  href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>

<nav>
<ul class="navbar">
<?php echo $page->getMenu(); ?>
</ul>
</nav>
<br>
<br>
<br>
<h1>Welcome</h1>
<br>
<p> Welcome to The Local Theatre!</p>
<br>
<p> Please use the navigation bar to log in, register or view our blog.</p>
<br>
<p> Thank you for visiting us!</p>

</body>

<style>
p {
	text-align: center;
	font-size: 20px;
}

</style>

</html>
