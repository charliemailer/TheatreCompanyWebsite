<!doctype html>
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
<?php
require_once("php/article.class.php");
require_once("php/articlecrud.class.php");
require_once("php/page.class.php");
$source=new ArticleCrud();
$page = new Page(3);
?>

<nav><ul class="navbar">
<?php echo $page->getMenu(); ?>
</ul></nav>

<a href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>

<main>
<?php
 $result=$source->deleteArticle($_GET["aid"]);
 if($result==1) {
	 echo "Article has been deleted";
 }
?>
<button onclick="window.location.href = 'blog.php';">Back to blog</button>
</main>

</body>
</html>