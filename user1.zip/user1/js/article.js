'use strict'
function Article(parentElement) {
	this.parentElement=this.getTarget(parentElement);	
	
};

	Article.prototype.getTarget=function(target) {
		if(target.indexOf('#')!==-1) {
			// id passed
			return document.getElementById(target.substr(1));
		} else {
			//tagname passed get first occurrence
			return document.getElementsByTagName(target)[0];
		}
	};

//Cross platform support for the total height of the document
	Article.prototype.getDocHeight=function() {
		var d=document, b = d.body, e=d.documentElement;
		return Math.max(
		b.scrollHeight, e.scrollHeight,	b.offsetHeight, e.offsetHeight,	b.clientHeight, e.clientHeight
		);	
	};

	// Cross platform support for the inner height of the client window
	Article.prototype.getWinHeight=function() {
		var w=window, d=document, e=d.documentElement,g=d.getElementsByTagName('body')[0],
		y = w.innerHeight || e.clientHeight || g.clientHeight;
		return y;
	};

	// Cross platform support to get the Y coordinate of the top of the visible part of the page
	Article.prototype.getScrollPosition=function() {
		var w=window, d=document, e=d.documentElement;
		var scrollposition = (w.pageYOffset || e.scrollTop)  - (e.clientTop || 0);
		return scrollposition;
	}
	
	Article.prototype.toBottom=function() {
		return this.getDocHeight()-(this.getWinHeight()+this.getScrollPosition());
	};

	Article.prototype.check=function() {
		if(this.toBottom()<20 && typeof JSON==="object") {
			console.info("hit");
			var lastchild=this.parentElement.children.length-1;
			var timeelements=this.parentElement.children[lastchild].getElementsByTagName("time");
			this.blogpostdate=timeelements[0].getAttribute("datetime");
			console.log(this.blogpostdate);
			this.XHR=this.createXHR();
			this.getArticle();		

		}
	}
	
	/***************************
	* Create XHR - supported from IE9
	* ActiveXObject included as example
	***************************/
	Article.prototype.createXHR=function() {
		if (window.XMLHttpRequest) {
			return new XMLHttpRequest();
		}
		else if(window.ActiveXObject) {
			return new ActiveXObject("Microsoft.XMLHTTP");
		}
	};	

	Article.prototype.getArticle=function() {
		this.XHR.open("POST","php/getArticle.php",true);
		this.XHR.onreadystatechange = this.makeArticle.bind(this);
		// Send request
		this.XHR.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		this.XHR.send("blogpostdate="+encodeURIComponent(this.blogpostdate));
	};

	Article.prototype.makeArticle=function() {
		if(this.XHR.readyState==4) {
			if(this.XHR.status==200) { // Two stage status check for older IE
				// Get json array returned					
				var responsearray=JSON.parse(this.XHR.responseText);
				if(responsearray[0].id) {
					var responsedata=responsearray[0];
					var articledate=new Date(responsedata.date);
					var adateonly=articledate.getUTCFullYear()+"-"+articledate.getUTCMonth()+"-"+articledate.getUTCDate();
					var atimeonly=articledate.getUTCHours()+":"+articledate.getUTCMinutes()+":"+articledate.getUTCSeconds();
					console.log(adateonly+" "+atimeonly);
					var newHTML="<article><h1>"+responsedata.title+"</h1><div id='"+responsedata.id+"'><footer><h2>Written by "+responsedata.author+"</h2><p> on <time datetime='"+responsedata.date+"'>"+adateonly+" at "+atimeonly+"</time></p></footer><p>"+responsedata.content+"</p>";
					var amenuHTML="	<ul class='articlemenu'>"+(responsedata.edit?"		<li><a href='editarticle.php?aid="+responsedata.id+"'>Edit Article</a></li>":"")+(responsedata.delete?"	<li><a href='deletearticle.php?aid="+responsedata.id+"'>Delete Article</a></li>":"")+(responsedata.add?"		<li><a href='addcomment.php?aid="+responsedata.id+"'>Add Comment</a></li>":"")+"	</ul>	</div>	";
					var commentHTML="<section class='comments'>	<h2>Comments</h2>		";
					for(var i=0;i<responsedata.comments.length;i++) {
					commentHTML+="<aside id='"+responsedata.comments[i].cid+"'>			<p>"+responsedata.comments[i].content+"</p>			<footer>				<p>by "+responsedata.comments[i].username+" on "+responsedata.comments[i].date+"</p>";
					commentHTML+="<ul class='commentmenu'>					"+(responsedata.comments[i].edit?"<li><a href='editcomment.php?cid="+responsedata.comments[i].cid+"'>Edit</a></li>":"")+(responsedata.comments[i].delete?"					<li><a href='deletecomment.php?cid="+responsedata.comments[i].cid+"'>Delete</a></li>":"")+"	</ul></footer>	</aside>";
					}
					var endHTML="</section></article>";
					this.parentElement.insertAdjacentHTML("beforeend",newHTML+amenuHTML+commentHTML+endHTML);
					
				}

			}
		}
	}