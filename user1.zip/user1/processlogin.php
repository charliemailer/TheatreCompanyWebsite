<!doctype html>
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>

<a href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>


<?php
require_once("php/page.class.php");
try {
	$username=$_POST['username'];
	$userpass=$_POST['userpass'];
	$page=new Page();
	$page->login($username,$userpass);
} catch(Exception $e) {
	echo "Error : ", $e->getMessage();

}
?>
<script>
function goBack() {
  window.history.back();
}
</script>
<button onclick="goBack()">Go Back</button>
</body>
</html>