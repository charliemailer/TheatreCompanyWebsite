<!doctype html>
<head>
<link rel="stylesheet" type="text/css" href="style/style.css">
<?php
require_once("php/page.class.php");
$page = new Page(0);
?>
<meta charset="UTF-8" />
</head>
<body>
<a href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>
<nav>
<ul class="navbar">
<?php echo $page->getMenu(); ?>
</ul>
</nav>
<?php
require_once("php/user.class.php");
try {
	$username=$_POST['username'];
	$firstname=$_POST['firstname'];
	$surname=$_POST['surname'];
	$email=$_POST['email'];
	$dob=$_POST['dob'];
	$userpass=$_POST['userpass'];
	$reguser=new User();
	$result=$reguser->registerUser($username,$userpass,$firstname,$surname,$email,$dob);
	if($result['insert']==1) {
		echo "User Registered<br />";
		?>
		<form method="post" action="processlogin.php">
			<label for="username">Username</label><input type="text" name="username" id="username" <?php echo "value='",$username,"' "; ?>/><br />
			<label for="password">Password</label><input type="password" name="userpass" id="userpass" /><br />
			<button type="submit">Login</button>
		</form>
		<?php
		echo "Re-enter your password to login<br/>";
	}	else {
		echo $result['messages'];
		?><a href="javascript:history.back(-1);">Back to Registration Form</a><?php
	}
	
} catch (Exception $e) {
	echo "Error : ", $e->getMessage();
}
?>
</body>
</html>