<!doctype html>
<head>
<link rel="stylesheet" type="text/css" href="style/style.css">
<?php
require_once("php/page.class.php");
$page = new Page();
?>
<meta charset="UTF-8" />
</head>
<body>

<a href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a>

<nav>
<ul class="navbar">
<?php echo $page->getMenu(); ?>
</ul>
</nav>
<h1>Login</h1>
<br>
<br>
<br>
<form method="post" action="processlogin.php">
<label for="username">Username</label><input type="text" name="username" id="username" /><br />
<label for="password">Password</label><input type="password" name="userpass" id="userpass" /><br />
<button type="submit">Login</button>
</form>
</body>
</html>