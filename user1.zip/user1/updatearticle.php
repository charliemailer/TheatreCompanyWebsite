<!doctype html> <head><link rel="stylesheet" type="text/css" href="style/style.css"> </head><body><a  href = "home.php" class="navbar-brand">
      <div class="logo-image">
            <img src="assets/logowithtext.jpg" class="img-fluid">
      </div>
</a></body></html>
<?php
require_once("php/articlecrud.class.php");
require_once("php/article.class.php");
$page = new Page(3);
try {
	if(util::valInt($_POST['aid'])) {$aid=$_POST['aid'];}
	
	$title=(util::posted($_POST['title'])?$_POST['title']:"");
	$content=(util::posted($_POST['content'])?$_POST['content']:"");
	$result=$page->updateArticle($title, $content);
	if($result['update']==1) {
		echo "Article updated<br />";
	} else {
		echo "Article Failed:<br>";
		echo $result['messages'];
	}
	?><p><a href="admin.php">Back to Admin page</a></p><?php
} catch (Exception $e) {
	echo "Error : ", $e->getMessage();
}
?>